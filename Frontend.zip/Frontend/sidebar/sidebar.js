function toggleSubmenu(event) {
  if (event) event.preventDefault(); // Previne o comportamento padrão do link
  const submenu = document.getElementById("cadastro-submenu");
  if (submenu) {
    submenu.classList.toggle("active"); // Adiciona ou remove a classe 'active'
    // Opcional: Adiciona/remove uma classe para o próprio item de menu-toggle para controlar a seta
    const menuToggleItem = event.target.closest(".menu-toggle");
    if (menuToggleItem) {
      menuToggleItem.classList.toggle("open");
    }
  }
}

function carregarTela(event, caminho) {
  if (event) event.preventDefault();
  fetch(`/cadastro/${caminho}/index.html`)
    .then(res => res.text())
    .then(html => {
      const container = document.getElementById("conteudo");
      if (container) {
        container.innerHTML = html;
      }
    })
    .catch(() => {
      document.getElementById("conteudo").innerHTML = "<p>Erro ao carregar a tela.</p>";
    });
}